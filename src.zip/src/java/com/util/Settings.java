/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.util;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 *
 * @author ManikTech
 */
public class Settings {
     public final int PASSPORT_HEIGHT = 132;
    public final int PASSPORT_WIDTH = 170;

    public String getMonthName(String month1) {
        //TODO implement getMonthName
        String monthName = null;
        int month = new Integer(month1);
        switch (month) {
            case 1:
                monthName = "JANUARY";
                break;
            case 2:
                monthName = "FEBRUARY";
                break;
            case 3:
                monthName = "MARCH";
                break;
            case 4:
                monthName = "APRIL";
                break;
            case 5:
                monthName = "MAY";
                break;
            case 6:
                monthName = "JUNE";
                break;
            case 7:
                monthName = "JULY";
                break;
            case 8:
                monthName = "AUGUST";
                break;
            case 9:
                monthName = "SEPTEMBER";
                break;
            case 10:
                monthName = "OCTOBER";
                break;
            case 11:
                monthName = "NOVEMBER";
                break;
            case 12:
                monthName = "DECEMBER";
                break;
        }
        return monthName;
    }

    public String getMonthNameShort(String month1) {
        //TODO implement getMonthName
        String monthName = null;
        int month = new Integer(month1);
        switch (month) {
            case 1:
                monthName = "JAN";
                break;
            case 2:
                monthName = "FEB";
                break;
            case 3:
                monthName = "MAR";
                break;
            case 4:
                monthName = "APR";
                break;
            case 5:
                monthName = "MAY";
                break;
            case 6:
                monthName = "JUN";
                break;
            case 7:
                monthName = "JUL";
                break;
            case 8:
                monthName = "AUG";
                break;
            case 9:
                monthName = "SEP";
                break;
            case 10:
                monthName = "OCT";
                break;
            case 11:
                monthName = "NOV";
                break;
            case 12:
                monthName = "DEC";
                break;
        }
        return monthName;
    }

    public double Round(double number, int decimalPlaces) {
        double modifier = Math.pow(10.0, decimalPlaces);
        return Math.round(number * modifier) / modifier;
    }

    public String getCurrentTime() {
        String hr1;
        String min1;
        String sec1;
        java.util.Calendar cal = new java.util.GregorianCalendar();
        int hr = cal.get(GregorianCalendar.HOUR_OF_DAY);
        int min = cal.get(GregorianCalendar.MINUTE);
        int sec = cal.get(GregorianCalendar.SECOND);
        if (Integer.toString(hr).length() < 2) {
            hr1 = "0" + hr;
        } else {
            hr1 = hr + "";
        }
        if (Integer.toString(min).length() < 2) {
            min1 = "0" + min;
        } else {
            min1 = min + "";
        }
        if (Integer.toString(sec).length() < 2) {
            sec1 = "0" + sec;
        } else {
            sec1 = sec + "";
        }

        String TIME = hr1 + ":" + min1 + ":" + sec1;
        return TIME;
    }

    public String getTodaysdate() {
        String month1;
        String day1;
        java.util.Calendar cal = new java.util.GregorianCalendar();
        int year = cal.get(GregorianCalendar.YEAR);
        int month = (cal.get(GregorianCalendar.MONTH) + 1);
        int day = cal.get(GregorianCalendar.DATE);
        if (Integer.toString(month).length() < 2) {
            month1 = "0" + month;
        } else {
            month1 = month + "";
        }
        if (Integer.toString(day).length() < 2) {
            day1 = "0" + day;
        } else {
            day1 = day + "";
        }

        String TODAY = year + "-" + month1 + "-" + day1;
        return TODAY;
    }

    public int getCurrentAge(String dob) {
        int age = 0;
        try {
            String today = getTodaysdate();
            String[] std = today.split("-");
            String[] sdob = dob.split("-");
            int dyy = 0, dmm = 0, ddd = 0;
            int cyy = 0, cmm = 0, cdd = 0;
            int ayy = 0, amm = 0;

            try {
                dyy = Integer.parseInt(sdob[0]);
                dmm = Integer.parseInt(sdob[1]);
                ddd = Integer.parseInt(sdob[2]);

                cyy = Integer.parseInt(std[0]);
                cmm = Integer.parseInt(std[1]);
                cdd = Integer.parseInt(std[2]);

                ayy = cyy - dyy;
                if (dmm > cmm) {
                    ayy--;
                }
                if (dmm == cmm) {
                    if (ddd > cdd) {
                        ayy--;
                    }
                }

            } catch (Exception a) {
            }
        } catch (Exception ss) {
        }
        return age;
    }

    public String[] getStatesInNigeria() {
        String[] st = {"Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno",
            "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT", "Gombe",
            "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos",
            "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers",
            "Sokoto", "Taraba", "Yobe", "Zamfara"
        };
        return st;
    }

    public String getPincodes(int size) {
        String pin;
        Random ra = new Random();
        long l1 = ra.nextLong() % 100000000;
        if (l1 < 0) {
            l1 = (-1) * l1;
        }
        long l2 = ra.nextLong() % 100000000;
        if (l2 < 0) {
            l2 = (-1) * l2;
        }
        long l3 = ra.nextLong() % 100000000;
        if (l3 < 0) {
            l3 = (-1) * l3;
        }
        long l4 = ra.nextLong() % 100000000;
        if (l4 < 0) {
            l4 = (-1) * l4;
        }

        String f = Long.toString(l1) + Long.toString(l2) + Long.toString(l3) + Long.toString(l4);
        String cor = "1234567890987654321123456789";
        pin = (f + cor).substring(0, size);
        return pin;
    }

    public String currentDate1() {
        Calendar cal = new GregorianCalendar();
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        month++;
        String moh = "";
        String mo = "";
        if (month <= 9) {
            moh = "0" + String.valueOf(month);

        } else {
            moh = String.valueOf(month);
        }
        if (day <= 9) {
            mo = "0" + String.valueOf(day);

        } else {
            mo = String.valueOf(day);
        }
        return (year + "-" + moh + "-" + mo);
    }

    public String currentTime() {
        Calendar cal = new GregorianCalendar();
        int hour = cal.get(Calendar.HOUR);
        int minute = cal.get(Calendar.MINUTE);
        int seconds = cal.get(Calendar.SECOND);
        String hr1 = "";
        String min1 = "";
        String ec1 = "";
        if (new Integer(hour).toString().length() < 2) {
            hr1 = "0" + hour;
        } else {
            hr1 = hour + "";
        }
        if (new Integer(minute).toString().length() < 2) {
            min1 = "0" + minute;
        } else {
            min1 = minute + "";
        }
        if (new Integer(seconds).toString().length() < 2) {
            ec1 = "0" + seconds;
        } else {
            ec1 = seconds + "";
        }
        //hour++;
        return (hr1 + ":" + min1 + ":" + ec1);
    }

    public String currentDate() {
        Calendar cal = new GregorianCalendar();
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        month++;
        return new Integer(year).toString();
    }

    public String currentDateDay() {
        Calendar cal = new GregorianCalendar();
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        month++;
        return new Integer(day).toString();
    }

    public String currentDateMonth() {
        Calendar cal = new GregorianCalendar();
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        month++;
        return new Integer(month).toString();
    }
    
    public String generateEmployeeID() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 8) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }
    public String randNum() {
        String p = "";
        String r = "";
        int m = 0;
        int n = 0;
        int negativeno = -1;
        String addup = "";
        Random ranum = new Random();
        m = ranum.nextInt() * 1000;
        n = ranum.nextInt() * 1000;
        if (m < 0) {
            m = m / negativeno;
        }
        if (n < 0) {
            n = n / negativeno;
        }
        p = Integer.toString(m).substring(0, 5);
        r = Integer.toString(n).substring(0, 5);
        addup = p + r;
        return addup;
    }
    
     private static final String[] tensNames = {
        "",
        " Ten",
        " Twenty",
        " Thirty",
        " Forty",
        " Fifty",
        " Sixty",
        " Seventy",
        " Eighty",
        " Ninety"
    };
    private static final String[] numNames = {
        "",
        " One",
        " Two",
        " Three",
        " Four",
        " Five",
        " Six",
        " Seven",
        " Eight",
        " Nine",
        " Ten",
        " Eleven",
        " Twelve",
        " Thirteen",
        " Fourteen",
        " Fifteen",
        " Sixteen",
        " Seventeen",
        " Eighteen",
        " Nineteen"
    };

    //private EnglishNumberToWords() {}
    private static String convertLessThanOneThousand(int number) {
        String soFar;

        if (number % 100 < 20) {
            soFar = numNames[number % 100];
            number /= 100;
        } else {
            soFar = numNames[number % 10];
            number /= 10;

            soFar = tensNames[number % 10] + soFar;
            number /= 10;
        }
        if (number == 0) {
            return soFar;
        }
        return numNames[number] + " Hundred" + soFar;
    }

  
    public String convert(long number) {
        // 0 to 999 999 999 999
        if (number == 0) {
            return "Zero";
        }

        String snumber = Long.toString(number);

        // pad with "0"
        String mask = "000000000000";
        DecimalFormat df = new DecimalFormat(mask);
        snumber = df.format(number);

        // XXXnnnnnnnnn
        int billions = Integer.parseInt(snumber.substring(0, 3));
        // nnnXXXnnnnnn
        int millions = Integer.parseInt(snumber.substring(3, 6));
        // nnnnnnXXXnnn
        int hundredThousands = Integer.parseInt(snumber.substring(6, 9));
        // nnnnnnnnnXXX
        int thousands = Integer.parseInt(snumber.substring(9, 12));

        String tradBillions;
        switch (billions) {
            case 0:
                tradBillions = "";
                break;
            case 1:
                tradBillions = convertLessThanOneThousand(billions)
                        + " Billion ";
                break;
            default:
                tradBillions = convertLessThanOneThousand(billions)
                        + " Billion ";
        }
        String result = tradBillions;

        String tradMillions;
        switch (millions) {
            case 0:
                tradMillions = "";
                break;
            case 1:
                tradMillions = convertLessThanOneThousand(millions)
                        + " Million ";
                break;
            default:
                tradMillions = convertLessThanOneThousand(millions)
                        + " Million ";
        }
        result = result + tradMillions;

        String tradHundredThousands;
        switch (hundredThousands) {
            case 0:
                tradHundredThousands = "";
                break;
            case 1:
                tradHundredThousands = "One Thousand ";
                break;
            default:
                tradHundredThousands = convertLessThanOneThousand(hundredThousands)
                        + " Thousand ";
        }
        result = result + tradHundredThousands;

        String tradThousand;
        tradThousand = convertLessThanOneThousand(thousands);
        result = result + tradThousand;

        // remove extra spaces!
        return result.replaceAll("^\\s+", "").replaceAll("\\b\\s{2,}\\b", " ");
    }
public byte[] scaleImage(byte[] fileData, int width, int height) {
        ByteArrayInputStream in = new ByteArrayInputStream(fileData);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            BufferedImage img = ImageIO.read(in);
            if (height == 0) {
                height = (width * img.getHeight()) / img.getWidth();
            }
            if (width == 0) {
                width = (height * img.getWidth()) / img.getHeight();
            }
            Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            BufferedImage imageBuff = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            imageBuff.getGraphics().drawImage(scaledImage, 0, 0, new Color(0, 0, 0), null);

            ImageIO.write(imageBuff, "jpg", buffer);
        } catch (IOException e) {
        }
        return buffer.toByteArray();
    }

public byte[] scale(byte[] fileData, int width, int height) {
        ByteArrayInputStream in = new ByteArrayInputStream(fileData);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            BufferedImage img = ImageIO.read(in);
            if (height == 0) {
                height = (width * img.getHeight()) / img.getWidth();
            }
            if (width == 0) {
                width = (height * img.getWidth()) / img.getHeight();
            }
            Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            BufferedImage imageBuff = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            imageBuff.getGraphics().drawImage(scaledImage, 0, 0, new Color(0, 0, 0), null);

            ImageIO.write(imageBuff, "jpg", buffer);
        } catch (IOException e) {
        }
        return buffer.toByteArray();
    }
}
