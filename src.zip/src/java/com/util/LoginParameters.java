/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.util;

/**
 *
 * @author ayua
 */
public class LoginParameters {
    private final String username;
    private final String roles;
    private final String defaulthome;
    private final String pages;
    private final String menu;

    public LoginParameters(String username, String roles, String defaulthome, String pages, String menu) {
        this.username = username;
        this.roles = roles;
        this.defaulthome = defaulthome;
        this.pages = pages;
        this.menu = menu;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the roles
     */
    public String getRoles() {
        return roles;
    }

    /**
     * @return the pages
     */
    public String getPages() {
        return pages;
    }

    /**
     * @return the menu
     */
    public String getMenu() {
        return menu;
    }

    /**
     * @return the defaulthome
     */
    public String getDefaulthome() {
        return defaulthome;
    }
    
}
