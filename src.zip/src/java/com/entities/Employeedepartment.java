/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "employeedepartment")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Employeedepartment.findAll", query = "SELECT e FROM Employeedepartment e")
    , @NamedQuery(name = "Employeedepartment.findById", query = "SELECT e FROM Employeedepartment e WHERE e.id = :id")
    , @NamedQuery(name = "Employeedepartment.findByEmployeeID", query = "SELECT e FROM Employeedepartment e WHERE e.employeeID = :employeeID")
    , @NamedQuery(name = "Employeedepartment.findByDepartment", query = "SELECT e FROM Employeedepartment e WHERE e.department = :department")
    , @NamedQuery(name = "Employeedepartment.findByJobTitle", query = "SELECT e FROM Employeedepartment e WHERE e.jobTitle = :jobTitle")
    , @NamedQuery(name = "Employeedepartment.findByRank", query = "SELECT e FROM Employeedepartment e WHERE e.rank = :rank")
    , @NamedQuery(name = "Employeedepartment.findByStatus", query = "SELECT e FROM Employeedepartment e WHERE e.status = :status")})
public class Employeedepartment implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "id")
    private String id;
    @Size(max = 45)
    @Column(name = "employeeID")
    private String employeeID;
    @Size(max = 45)
    @Column(name = "department")
    private String department;
    @Size(max = 45)
    @Column(name = "jobTitle")
    private String jobTitle;
    @Lob
    @Size(max = 65535)
    @Column(name = "qalifications")
    private String qalifications;
    @Lob
    @Size(max = 65535)
    @Column(name = "areaSpecialize")
    private String areaSpecialize;
    @Size(max = 45)
    @Column(name = "rank")
    private String rank;
    @Size(max = 45)
    @Column(name = "status")
    private String status;

    public Employeedepartment() {
    }

    public Employeedepartment(String id, String employeeID, String department, String jobTitle, String qalifications, String areaSpecialize, String rank, String status) {
        this.id = id;
        this.employeeID = employeeID;
        this.department = department;
        this.jobTitle = jobTitle;
        this.qalifications = qalifications;
        this.areaSpecialize = areaSpecialize;
        this.rank = rank;
        this.status = status;
    }

    public Employeedepartment(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getQalifications() {
        return qalifications;
    }

    public void setQalifications(String qalifications) {
        this.qalifications = qalifications;
    }

    public String getAreaSpecialize() {
        return areaSpecialize;
    }

    public void setAreaSpecialize(String areaSpecialize) {
        this.areaSpecialize = areaSpecialize;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employeedepartment)) {
            return false;
        }
        Employeedepartment other = (Employeedepartment) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Employeedepartment[ id=" + id + " ]";
    }
    
}
