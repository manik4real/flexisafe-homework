/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "pages")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pages.findAll", query = "SELECT p FROM Pages p")
    , @NamedQuery(name = "Pages.findByPageid", query = "SELECT p FROM Pages p WHERE p.pageid = :pageid")
    , @NamedQuery(name = "Pages.findByDatecreated", query = "SELECT p FROM Pages p WHERE p.datecreated = :datecreated")
    , @NamedQuery(name = "Pages.findByDescription", query = "SELECT p FROM Pages p WHERE p.description = :description")
    , @NamedQuery(name = "Pages.findByPagename", query = "SELECT p FROM Pages p WHERE p.pagename = :pagename")
    , @NamedQuery(name = "Pages.findByMenuid", query = "SELECT p FROM Pages p WHERE p.menuid = :menuid")
    , @NamedQuery(name = "Pages.findByRoleids", query = "SELECT p FROM Pages p WHERE p.roleids = :roleids")
    , @NamedQuery(name = "Pages.findByStatus", query = "SELECT p FROM Pages p WHERE p.status = :status")
    , @NamedQuery(name = "Pages.findByStatuscomment", query = "SELECT p FROM Pages p WHERE p.statuscomment = :statuscomment")
    , @NamedQuery(name = "Pages.findByProcessid", query = "SELECT p FROM Pages p WHERE p.processid = :processid")})
public class Pages implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "pageid")
    private String pageid;
    @Size(max = 255)
    @Column(name = "datecreated")
    private String datecreated;
    @Size(max = 255)
    @Column(name = "description")
    private String description;
    @Size(max = 255)
    @Column(name = "pagename")
    private String pagename;
    @Size(max = 255)
    @Column(name = "menuid")
    private String menuid;
    @Size(max = 255)
    @Column(name = "roleids")
    private String roleids;
    @Size(max = 255)
    @Column(name = "status")
    private String status;
    @Size(max = 255)
    @Column(name = "statuscomment")
    private String statuscomment;
    @Size(max = 255)
    @Column(name = "processid")
    private String processid;

    public Pages() {
    }

    public Pages(String pageid) {
        this.pageid = pageid;
    }

    public String getPageid() {
        return pageid;
    }

    public void setPageid(String pageid) {
        this.pageid = pageid;
    }

    public String getDatecreated() {
        return datecreated;
    }

    public void setDatecreated(String datecreated) {
        this.datecreated = datecreated;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPagename() {
        return pagename;
    }

    public void setPagename(String pagename) {
        this.pagename = pagename;
    }

    public String getMenuid() {
        return menuid;
    }

    public void setMenuid(String menuid) {
        this.menuid = menuid;
    }

    public String getRoleids() {
        return roleids;
    }

    public void setRoleids(String roleids) {
        this.roleids = roleids;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatuscomment() {
        return statuscomment;
    }

    public void setStatuscomment(String statuscomment) {
        this.statuscomment = statuscomment;
    }

    public String getProcessid() {
        return processid;
    }

    public void setProcessid(String processid) {
        this.processid = processid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pageid != null ? pageid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pages)) {
            return false;
        }
        Pages other = (Pages) object;
        if ((this.pageid == null && other.pageid != null) || (this.pageid != null && !this.pageid.equals(other.pageid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Pages[ pageid=" + pageid + " ]";
    }
    
}
