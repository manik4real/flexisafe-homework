/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "nextofkin")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Nextofkin.findAll", query = "SELECT n FROM Nextofkin n")
    , @NamedQuery(name = "Nextofkin.findById", query = "SELECT n FROM Nextofkin n WHERE n.id = :id")
    , @NamedQuery(name = "Nextofkin.findByFullname", query = "SELECT n FROM Nextofkin n WHERE n.fullname = :fullname")
    , @NamedQuery(name = "Nextofkin.findByGender", query = "SELECT n FROM Nextofkin n WHERE n.gender = :gender")
    , @NamedQuery(name = "Nextofkin.findByRelationship", query = "SELECT n FROM Nextofkin n WHERE n.relationship = :relationship")
    , @NamedQuery(name = "Nextofkin.findByPhone", query = "SELECT n FROM Nextofkin n WHERE n.phone = :phone")
    , @NamedQuery(name = "Nextofkin.findByAddress", query = "SELECT n FROM Nextofkin n WHERE n.address = :address")
    , @NamedQuery(name = "Nextofkin.findByOccupation", query = "SELECT n FROM Nextofkin n WHERE n.occupation = :occupation")
    , @NamedQuery(name = "Nextofkin.findByEmployeeID", query = "SELECT n FROM Nextofkin n WHERE n.employeeID = :employeeID")
    , @NamedQuery(name = "Nextofkin.findByStatus", query = "SELECT n FROM Nextofkin n WHERE n.status = :status")})
public class Nextofkin implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "id")
    private String id;
    @Size(max = 45)
    @Column(name = "fullname")
    private String fullname;
    @Size(max = 45)
    @Column(name = "gender")
    private String gender;
    @Size(max = 45)
    @Column(name = "relationship")
    private String relationship;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Size(max = 45)
    @Column(name = "phone")
    private String phone;
    @Size(max = 45)
    @Column(name = "address")
    private String address;
    @Size(max = 45)
    @Column(name = "occupation")
    private String occupation;
    @Size(max = 45)
    @Column(name = "employeeID")
    private String employeeID;
    @Size(max = 45)
    @Column(name = "status")
    private String status;

    public Nextofkin() {
    }

    public Nextofkin(String id, String fullname, String gender, String relationship, String phone, String address, String occupation, String employeeID, String status) {
        this.id = id;
        this.fullname = fullname;
        this.gender = gender;
        this.relationship = relationship;
        this.phone = phone;
        this.address = address;
        this.occupation = occupation;
        this.employeeID = employeeID;
        this.status = status;
    }

    public Nextofkin(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Nextofkin)) {
            return false;
        }
        Nextofkin other = (Nextofkin) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Nextofkin[ id=" + id + " ]";
    }
    
}
