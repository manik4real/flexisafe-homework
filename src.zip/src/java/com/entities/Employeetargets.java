/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "employeetargets")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Employeetargets.findAll", query = "SELECT e FROM Employeetargets e")
    , @NamedQuery(name = "Employeetargets.findByTargetid", query = "SELECT e FROM Employeetargets e WHERE e.targetid = :targetid")
    , @NamedQuery(name = "Employeetargets.findByProjectID", query = "SELECT e FROM Employeetargets e WHERE e.projectID = :projectID")
    , @NamedQuery(name = "Employeetargets.findByEmployeeID", query = "SELECT e FROM Employeetargets e WHERE e.employeeID = :employeeID")
    , @NamedQuery(name = "Employeetargets.findByDateAssigned", query = "SELECT e FROM Employeetargets e WHERE e.dateAssigned = :dateAssigned")
    , @NamedQuery(name = "Employeetargets.findByDateSubmited", query = "SELECT e FROM Employeetargets e WHERE e.dateSubmited = :dateSubmited")
    , @NamedQuery(name = "Employeetargets.findByStatus", query = "SELECT e FROM Employeetargets e WHERE e.status = :status")
    , @NamedQuery(name = "Employeetargets.findByApproval", query = "SELECT e FROM Employeetargets e WHERE e.approval = :approval")})
public class Employeetargets implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "targetid")
    private String targetid;
    @Size(max = 45)
    @Column(name = "projectID")
    private String projectID;
    @Size(max = 45)
    @Column(name = "employeeID")
    private String employeeID;
    @Size(max = 45)
    @Column(name = "dateAssigned")
    private String dateAssigned;
    @Size(max = 45)
    @Column(name = "dateSubmited")
    private String dateSubmited;
    @Size(max = 45)
    @Column(name = "status")
    private String status;
    @Size(max = 45)
    @Column(name = "approval")
    private String approval;

    public Employeetargets() {
    }

    public Employeetargets(String targetid, String projectID, String employeeID, String dateAssigned, String dateSubmited, String status, String approval) {
        this.targetid = targetid;
        this.projectID = projectID;
        this.employeeID = employeeID;
        this.dateAssigned = dateAssigned;
        this.dateSubmited = dateSubmited;
        this.status = status;
        this.approval = approval;
    }

    public Employeetargets(String targetid) {
        this.targetid = targetid;
    }

    public String getTargetid() {
        return targetid;
    }

    public void setTargetid(String targetid) {
        this.targetid = targetid;
    }

    public String getProjectID() {
        return projectID;
    }

    public void setProjectID(String projectID) {
        this.projectID = projectID;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getDateAssigned() {
        return dateAssigned;
    }

    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    public String getDateSubmited() {
        return dateSubmited;
    }

    public void setDateSubmited(String dateSubmited) {
        this.dateSubmited = dateSubmited;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getApproval() {
        return approval;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (targetid != null ? targetid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employeetargets)) {
            return false;
        }
        Employeetargets other = (Employeetargets) object;
        if ((this.targetid == null && other.targetid != null) || (this.targetid != null && !this.targetid.equals(other.targetid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Employeetargets[ targetid=" + targetid + " ]";
    }
    
}
