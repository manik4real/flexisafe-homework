/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "userlogin")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Userlogin.findAll", query = "SELECT u FROM Userlogin u")
    , @NamedQuery(name = "Userlogin.findByUsername", query = "SELECT u FROM Userlogin u WHERE u.username = :username")
    , @NamedQuery(name = "Userlogin.findByPassword", query = "SELECT u FROM Userlogin u WHERE u.password = :password")
    , @NamedQuery(name = "Userlogin.findByDatelastlogin", query = "SELECT u FROM Userlogin u WHERE u.datelastlogin = :datelastlogin")
    , @NamedQuery(name = "Userlogin.findByTimelastlogin", query = "SELECT u FROM Userlogin u WHERE u.timelastlogin = :timelastlogin")
    , @NamedQuery(name = "Userlogin.findByLocaltimlogin", query = "SELECT u FROM Userlogin u WHERE u.localtimlogin = :localtimlogin")
    , @NamedQuery(name = "Userlogin.findByRoleid", query = "SELECT u FROM Userlogin u WHERE u.roleid = :roleid")
    , @NamedQuery(name = "Userlogin.findByStatus", query = "SELECT u FROM Userlogin u WHERE u.status = :status")
    , @NamedQuery(name = "Userlogin.findByStatuscomment", query = "SELECT u FROM Userlogin u WHERE u.statuscomment = :statuscomment")})
public class Userlogin implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "username")
    private String username;
    @Size(max = 255)
    @Column(name = "password")
    private String password;
    @Size(max = 255)
    @Column(name = "datelastlogin")
    private String datelastlogin;
    @Size(max = 255)
    @Column(name = "timelastlogin")
    private String timelastlogin;
    @Size(max = 255)
    @Column(name = "localtimlogin")
    private String localtimlogin;
    @Size(max = 255)
    @Column(name = "roleid")
    private String roleid;
    @Size(max = 255)
    @Column(name = "status")
    private String status;
    @Size(max = 255)
    @Column(name = "statuscomment")
    private String statuscomment;

    public Userlogin() {
    }

    public Userlogin(String username, String password, String datelastlogin, String timelastlogin, String localtimlogin, String roleid, String status, String statuscomment) {
        this.username = username;
        this.password = password;
        this.datelastlogin = datelastlogin;
        this.timelastlogin = timelastlogin;
        this.localtimlogin = localtimlogin;
        this.roleid = roleid;
        this.status = status;
        this.statuscomment = statuscomment;
    }

    public Userlogin(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDatelastlogin() {
        return datelastlogin;
    }

    public void setDatelastlogin(String datelastlogin) {
        this.datelastlogin = datelastlogin;
    }

    public String getTimelastlogin() {
        return timelastlogin;
    }

    public void setTimelastlogin(String timelastlogin) {
        this.timelastlogin = timelastlogin;
    }

    public String getLocaltimlogin() {
        return localtimlogin;
    }

    public void setLocaltimlogin(String localtimlogin) {
        this.localtimlogin = localtimlogin;
    }

    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatuscomment() {
        return statuscomment;
    }

    public void setStatuscomment(String statuscomment) {
        this.statuscomment = statuscomment;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (username != null ? username.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userlogin)) {
            return false;
        }
        Userlogin other = (Userlogin) object;
        if ((this.username == null && other.username != null) || (this.username != null && !this.username.equals(other.username))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Userlogin[ username=" + username + " ]";
    }
    
}
