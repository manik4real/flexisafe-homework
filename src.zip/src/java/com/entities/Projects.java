/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "projects")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Projects.findAll", query = "SELECT p FROM Projects p")
    , @NamedQuery(name = "Projects.findByProjectid", query = "SELECT p FROM Projects p WHERE p.projectid = :projectid")
    , @NamedQuery(name = "Projects.findByDateStarted", query = "SELECT p FROM Projects p WHERE p.dateStarted = :dateStarted")
    , @NamedQuery(name = "Projects.findByDateToEnd", query = "SELECT p FROM Projects p WHERE p.dateToEnd = :dateToEnd")
    , @NamedQuery(name = "Projects.findByDateEnded", query = "SELECT p FROM Projects p WHERE p.dateEnded = :dateEnded")
    , @NamedQuery(name = "Projects.findByNoEmployees", query = "SELECT p FROM Projects p WHERE p.noEmployees = :noEmployees")
    , @NamedQuery(name = "Projects.findByEstimatedCost", query = "SELECT p FROM Projects p WHERE p.estimatedCost = :estimatedCost")
    , @NamedQuery(name = "Projects.findByRealCost", query = "SELECT p FROM Projects p WHERE p.realCost = :realCost")
    , @NamedQuery(name = "Projects.findByState", query = "SELECT p FROM Projects p WHERE p.state = :state")})
public class Projects implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "projectid")
    private String projectid;
    @Lob
    @Size(max = 65535)
    @Column(name = "description")
    private String description;
    @Size(max = 45)
    @Column(name = "dateStarted")
    private String dateStarted;
    @Size(max = 45)
    @Column(name = "dateToEnd")
    private String dateToEnd;
    @Size(max = 45)
    @Column(name = "dateEnded")
    private String dateEnded;
    @Size(max = 45)
    @Column(name = "noEmployees")
    private String noEmployees;
    @Size(max = 45)
    @Column(name = "estimatedCost")
    private String estimatedCost;
    @Size(max = 45)
    @Column(name = "realCost")
    private String realCost;
    @Size(max = 45)
    @Column(name = "state")
    private String state;

    public Projects() {
    }

    public Projects(String projectid, String description, String dateStarted, String dateToEnd, String dateEnded, String noEmployees, String estimatedCost, String realCost, String state) {
        this.projectid = projectid;
        this.description = description;
        this.dateStarted = dateStarted;
        this.dateToEnd = dateToEnd;
        this.dateEnded = dateEnded;
        this.noEmployees = noEmployees;
        this.estimatedCost = estimatedCost;
        this.realCost = realCost;
        this.state = state;
    }

    public Projects(String projectid) {
        this.projectid = projectid;
    }

    public String getProjectid() {
        return projectid;
    }

    public void setProjectid(String projectid) {
        this.projectid = projectid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDateStarted() {
        return dateStarted;
    }

    public void setDateStarted(String dateStarted) {
        this.dateStarted = dateStarted;
    }

    public String getDateToEnd() {
        return dateToEnd;
    }

    public void setDateToEnd(String dateToEnd) {
        this.dateToEnd = dateToEnd;
    }

    public String getDateEnded() {
        return dateEnded;
    }

    public void setDateEnded(String dateEnded) {
        this.dateEnded = dateEnded;
    }

    public String getNoEmployees() {
        return noEmployees;
    }

    public void setNoEmployees(String noEmployees) {
        this.noEmployees = noEmployees;
    }

    public String getEstimatedCost() {
        return estimatedCost;
    }

    public void setEstimatedCost(String estimatedCost) {
        this.estimatedCost = estimatedCost;
    }

    public String getRealCost() {
        return realCost;
    }

    public void setRealCost(String realCost) {
        this.realCost = realCost;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (projectid != null ? projectid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Projects)) {
            return false;
        }
        Projects other = (Projects) object;
        if ((this.projectid == null && other.projectid != null) || (this.projectid != null && !this.projectid.equals(other.projectid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Projects[ projectid=" + projectid + " ]";
    }
    
}
