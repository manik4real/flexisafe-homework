/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "menus")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Menus.findAll", query = "SELECT m FROM Menus m")
    , @NamedQuery(name = "Menus.findByMenuid", query = "SELECT m FROM Menus m WHERE m.menuid = :menuid")
    , @NamedQuery(name = "Menus.findByMenuname", query = "SELECT m FROM Menus m WHERE m.menuname = :menuname")
    , @NamedQuery(name = "Menus.findByStatus", query = "SELECT m FROM Menus m WHERE m.status = :status")
    , @NamedQuery(name = "Menus.findByStatuscomment", query = "SELECT m FROM Menus m WHERE m.statuscomment = :statuscomment")})
public class Menus implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "menuid")
    private String menuid;
    @Size(max = 255)
    @Column(name = "menuname")
    private String menuname;
    @Size(max = 255)
    @Column(name = "status")
    private String status;
    @Size(max = 255)
    @Column(name = "statuscomment")
    private String statuscomment;

    public Menus() {
    }

    public Menus(String menuid) {
        this.menuid = menuid;
    }

    public String getMenuid() {
        return menuid;
    }

    public void setMenuid(String menuid) {
        this.menuid = menuid;
    }

    public String getMenuname() {
        return menuname;
    }

    public void setMenuname(String menuname) {
        this.menuname = menuname;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatuscomment() {
        return statuscomment;
    }

    public void setStatuscomment(String statuscomment) {
        this.statuscomment = statuscomment;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (menuid != null ? menuid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Menus)) {
            return false;
        }
        Menus other = (Menus) object;
        if ((this.menuid == null && other.menuid != null) || (this.menuid != null && !this.menuid.equals(other.menuid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Menus[ menuid=" + menuid + " ]";
    }
    
}
