/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ManikTech
 */
@Entity
@Table(name = "userloghistory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Userloghistory.findAll", query = "SELECT u FROM Userloghistory u")
    , @NamedQuery(name = "Userloghistory.findByTxid", query = "SELECT u FROM Userloghistory u WHERE u.txid = :txid")
    , @NamedQuery(name = "Userloghistory.findByUsername", query = "SELECT u FROM Userloghistory u WHERE u.username = :username")
    , @NamedQuery(name = "Userloghistory.findByDatelastlogin", query = "SELECT u FROM Userloghistory u WHERE u.datelastlogin = :datelastlogin")
    , @NamedQuery(name = "Userloghistory.findByTimelastlogin", query = "SELECT u FROM Userloghistory u WHERE u.timelastlogin = :timelastlogin")
    , @NamedQuery(name = "Userloghistory.findByLocationlogin", query = "SELECT u FROM Userloghistory u WHERE u.locationlogin = :locationlogin")})
public class Userloghistory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 225)
    @Column(name = "txid")
    private String txid;
    @Size(max = 225)
    @Column(name = "username")
    private String username;
    @Size(max = 225)
    @Column(name = "datelastlogin")
    private String datelastlogin;
    @Size(max = 225)
    @Column(name = "timelastlogin")
    private String timelastlogin;
    @Size(max = 45)
    @Column(name = "locationlogin")
    private String locationlogin;

    public Userloghistory() {
    }

    public Userloghistory(String txid, String username, String datelastlogin, String timelastlogin, String locationlogin) {
        this.txid = txid;
        this.username = username;
        this.datelastlogin = datelastlogin;
        this.timelastlogin = timelastlogin;
        this.locationlogin = locationlogin;
    }

   
    public Userloghistory(String txid) {
        this.txid = txid;
    }

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDatelastlogin() {
        return datelastlogin;
    }

    public void setDatelastlogin(String datelastlogin) {
        this.datelastlogin = datelastlogin;
    }

    public String getTimelastlogin() {
        return timelastlogin;
    }

    public void setTimelastlogin(String timelastlogin) {
        this.timelastlogin = timelastlogin;
    }

    public String getLocationlogin() {
        return locationlogin;
    }

    public void setLocationlogin(String locationlogin) {
        this.locationlogin = locationlogin;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (txid != null ? txid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userloghistory)) {
            return false;
        }
        Userloghistory other = (Userloghistory) object;
        if ((this.txid == null && other.txid != null) || (this.txid != null && !this.txid.equals(other.txid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Userloghistory[ txid=" + txid + " ]";
    }
    
}
