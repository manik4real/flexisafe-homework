/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sessions;

import com.entities.Department;
import com.entities.Employee;
import com.entities.Employeedepartment;
import com.entities.Employeepassport;
import com.entities.Employeetargets;
import com.entities.Menus;
import com.entities.Nextofkin;
import com.entities.Pages;
import com.entities.Projects;
import com.entities.Roles;
import com.entities.Userloghistory;
import com.entities.Userlogin;
import com.util.LoginParameters;
import com.util.Settings;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ManikTech
 */
@Stateless
public class EmployeeSession implements EmployeeSessionLocal {

    @PersistenceContext(unitName = "EmployeePU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    @Override
    public void persistNewEntry(Object obj) {
        //if(em.find(Object.class, obj.equals(obj)=null))
        try {
            em.persist(obj);
        } catch (Exception j) {
        }
    }

    @Override
    public void deleteObject(Object obj) {
        try {
            em.remove(obj);
        } catch (Exception j) {
        }
    }

    @Override
    public void updateRecord(Object obj) {
        try {
            em.merge(obj);
        } catch (Exception ja) {
        }

    }

    @Override
    public Object getSingleObject(Class<Object> ent, Object pk) {
        Object obj = null;
        try {
            obj = em.find(ent.getClass(), pk);
        } catch (Exception ja) {
        }
        return obj;
    }

    @Override
    public void upLoadPicture(String employeeID, byte[] pic) {

        Employeepassport mem = null;
        try {
            mem = (Employeepassport) em.find(Employeepassport.class, employeeID);
            mem.setPic(pic);
        } catch (Exception e) {
        }

    }

    @Override
    public byte[] viewVc(String employeeID) {
        Employeepassport mem = null;
        byte[] b = null;
        try {
            mem = (Employeepassport) em.find(Employeepassport.class, employeeID);
            b = mem.getPic();
        } catch (Exception e) {
        }
        return b;
    }

    @Override
    public boolean newEmployeePassport(Employeepassport param) {
        boolean rt = false;
        Employeepassport ap = em.find(Employeepassport.class, param.getId());
        if (ap == null) {
            em.persist(param);
            rt = true;
        } else {
            ap.setPic(param.getPic());
            em.merge(ap);
            rt = true;
        }
        return rt;
    }

    @Override
    public Employeepassport getEmployeePassport(String param) {
        return em.find(Employeepassport.class, param);
    }

    @Override
    public boolean removeEmployeePassport(String param) {
        boolean rt = false;
        Employeepassport ap = em.find(Employeepassport.class, param);
        if (ap != null) {
            em.remove(ap);
            rt = true;
        }
        return rt;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public Employee viewSingleEmployee(String employeeID) {
        return em.find(Employee.class, employeeID);
    }

    @Override
    public List<Nextofkin> viewEmployeeNextOfKing(String employeeID) {
        return em.createNamedQuery("Nextofkin.findByEmployeeID").setParameter("employeeID", employeeID).getResultList();
    }

    @Override
    public List<Employeedepartment> viewEmployeeDepartment(String employeeID) {
        return em.createNamedQuery("Employeedepartment.findByEmployeeID").setParameter("employeeID", employeeID).getResultList();
    }

    @Override
    public List<Employee> viewAllEmployee() {
        return em.createNamedQuery("Employee.findAll").getResultList();
    }

    @Override
    public void removeEmployeeDetails(String employeeID) {
        Employee cs = null;
        try {
            cs = em.find(Employee.class, employeeID);
            Employeepassport ap = em.find(Employeepassport.class, employeeID);
            Userlogin ul = em.find(Userlogin.class, employeeID);
            Employeedepartment ed = (Employeedepartment) em.createQuery("SELECT e FROM Employeedepartment e WHERE e.employeeID = :empid").setParameter("empid", employeeID).getSingleResult();
            Nextofkin nok = (Nextofkin) em.createQuery("SELECT n FROM Nextofkin n WHERE n.employeeID = :nokeid").setParameter("nokeid", employeeID).getSingleResult();
            em.remove(cs);
            // if(cs=null||cs1)
            em.remove(ap);
            em.remove(ul);
            em.remove(ed);
            em.remove(nok);
        } catch (Exception emp) {
            System.out.println("Error!! cannot remove Employee  from database due to:-" + emp.getMessage());
        }
    }

    //employeeID, title, fname, onames, gender, dob, maritalStatus, phone, email, contactAddress, homeaddress, 
    //lga, state, nationality, employmentDate, idCardType, idCardNumber, datecreated, status  
    @Override
    public String editEmployee(String employeeID, String title, String maritalStatus, String phone, String email, String contactAddress, String homeaddress, String idCardType, String idCardNumber) {
        String msg = "";
        Employee ep = em.find(Employee.class, employeeID);
        try {
            if (ep != null) {
                if (title != null) {
                    ep.setTitle(title);
                }
                if (maritalStatus != null) {
                    ep.setMaritalStatus(maritalStatus);
                }
                if (phone != null) {
                    ep.setPhone(phone);
                }
                if (email != null) {
                    ep.setEmail(email);
                }
                if (contactAddress != null) {
                    ep.setContactAddress(contactAddress);
                }
                if (homeaddress != null) {
                    ep.setHomeaddress(homeaddress);
                }
                if (idCardType != null) {
                    ep.setIdCardType(idCardType);
                }
                if (idCardType != null) {
                    ep.setIdCardType(idCardType);
                }
                msg = "<font color='green'>Employee Records Updated Successfully</font>";
            }
        } catch (Exception e) {
        }
        return msg;
    }

    @Override
    public Employeedepartment viewEmployeeDepartmentByEmployeeID(String employeeID) {
        Employeedepartment ed = null;
        try {
            ed = (Employeedepartment) em.createNamedQuery("SELECT e FROM Employeedepartment e WHERE e.employeeID = :employeeID").setParameter("employeeID", employeeID).getSingleResult();
        } catch (Exception e) {
        }
        return ed;
    }

    @Override
    public Nextofkin viewNextofKingByEmployeeID(String employeeID) {
        Nextofkin nok = null;
        try {
            nok = (Nextofkin) em.createNamedQuery("SELECT n FROM Nextofkin n WHERE n.employeeID = :employeeID").getSingleResult();
        } catch (Exception e) {
        };
        return nok;
    }
//id, employeeID, department, jobTitle, qalifications, areaSpecialize, rank, status

    @Override
    public String editEmployeeDepatement(String id, String department, String jobTitle, String qalifications, String areaSpecialize, String rank) {
        String msg = "";
        Employeedepartment ep = em.find(Employeedepartment.class, id);
        try {
            if (ep != null) {
                if (department != null) {
                    ep.setDepartment(department);
                }
                if (jobTitle != null) {
                    ep.setJobTitle(jobTitle);
                }
                if (qalifications != null) {
                    ep.setQalifications(qalifications);
                }
                if (areaSpecialize != null) {
                    ep.setAreaSpecialize(areaSpecialize);
                }
                if (rank != null) {
                    ep.setRank(rank);
                }
                msg = "<font color='green'>Employee Department Records Updated Successfully</font>";
            }
        } catch (Exception e) {
        }
        return msg;
    }
//id, fullname, gender, relationship, phone, address, occupation, employeeID, status    

    @Override
    public String editNextofKin(String id, String fullname, String gender, String relationship, String phone, String address, String occuption) {
        String msg = "";
        Nextofkin ep = em.find(Nextofkin.class, id);
        try {
            if (ep != null) {
                if (fullname != null) {
                    ep.setFullname(fullname);
                }
                if (gender != null) {
                    ep.setGender(gender);
                }
                if (relationship != null) {
                    ep.setRelationship(relationship);
                }
                if (phone != null) {
                    ep.setPhone(phone);
                }
                if (address != null) {
                    ep.setAddress(address);
                }
                if (occuption != null) {
                    ep.setOccupation(occuption);
                }
                msg = "<font color='green'>Employee Next of kin Records Updated Successfully</font>";
            }
        } catch (Exception e) {
        }
        return msg;
    }
    //Building Menu controls and login methods

    @Override
    public boolean newPages(Pages param) {
        boolean rt = false;
        Pages ap = em.find(Pages.class, param.getPageid());
        if (ap == null) {
            em.persist(param);
            rt = true;
        }
        return rt;
    }

    @Override
    public Pages getPages(String param) {
        return em.find(Pages.class, param);
    }

    @Override
    public List getAllPages() {
        List<Pages> menu = new ArrayList();
        try {
            menu = (List<Pages>) em.createNamedQuery("Pages.findAll").getResultList();
        } catch (Exception j) {
        }
        return menu;
    }

    @Override
    public Pages getPagesByName(String pagename) {
        Pages pages = null;
        try {
            List<Pages> l2 = (List<Pages>) em.createQuery("SELECT p FROM Pages p WHERE p.pagename = :pagename").setParameter("pagename", pagename).getResultList();
            for (Pages pa : l2) {
                pages = pa;
                break;
            }
        } catch (Exception s) {
        }
        return pages;
    }

    @Override
    public List<Pages> getAllPagesforRole(String roleid) {
        List<Pages> pages = new ArrayList();
        roleid = "%" + roleid + "%";
        try {
            pages = (List<Pages>) em.createQuery("SELECT p FROM Pages p WHERE p.roleids LIKE :roleid ORDER BY p.pagename ASC")
                    .setParameter("roleid", roleid).getResultList();
        } catch (Exception js) {
        }
        return pages;
    }

    @Override
    public boolean removePages(String param) {
        boolean rt = false;
        Pages ap = em.find(Pages.class, param);
        if (ap != null) {
            em.remove(ap);
            rt = true;
        }
        return rt;
    }

    @Override
    public boolean newRoles(Roles param) {
        boolean rt = false;
        Roles ap = em.find(Roles.class, param.getRoleid());
        if (ap == null) {
            em.persist(param);
            rt = true;
        }
        return rt;
    }

    @Override
    public Roles getRoles(String param) {
        return em.find(Roles.class, param);
    }

    @Override
    public List getAllRoles() {
        List<Roles> menu = new ArrayList();
        try {
            menu = (List<Roles>) em.createNamedQuery("Roles.findAll").getResultList();
        } catch (Exception j) {
        }
        return menu;
    }

    @Override
    public boolean removeRoles(String param) {
        boolean rt = false;
        if (em.find(Roles.class, param) != null) {
            em.remove(em.find(Roles.class, param));
            rt = true;
            //remove all users in this role
            String roleid = "%;" + param + "%";
            try {
                List<Userlogin> col = (List<Userlogin>) em.createQuery("SELECT u FROM Userlogin u WHERE u.roleid LIKE :roleid")
                        .setParameter("roleid", roleid).getResultList();
                for (Userlogin ul : col) {
                    String newroleid = ul.getRoleid().replace(roleid, "");
                    ul.setRoleid(newroleid);
                    em.merge(ul);
                }
            } catch (Exception jb) {
            }
            String rolex = "%;" + param + "%";
            try {
                List<Pages> col = (List<Pages>) em.createQuery("SELECT a FROM Pages a WHERE a.roleids LIKE :roles").setParameter("roles", rolex).getResultList();
                for (Pages pag : col) {
                    String newuser = pag.getRoleids().replace(rolex, "");
                    pag.setRoleids(newuser);
                    em.merge(pag);
                }
            } catch (Exception jb) {
            }
        }
        return rt;
    }

    @Override
    public boolean newUserloghistory(Userloghistory param) {
        boolean rt = false;
        Userloghistory ap = em.find(Userloghistory.class, param.getTxid());
        if (ap == null) {
            em.persist(param);
            rt = true;
        }
        return rt;
    }

    @Override
    public Userloghistory getUserloghistory(String param) {
        return em.find(Userloghistory.class, param);
    }

    @Override
    public boolean removeUserloghistory(String param) {
        boolean rt = false;
        Userloghistory ap = em.find(Userloghistory.class, param);
        if (ap != null) {
            em.remove(ap);
            rt = true;
        }
        return rt;
    }

    @Override
    public boolean newUserlogin(Userlogin param) {
        boolean rt = false;
        Userlogin ap = em.find(Userlogin.class, param.getUsername());
        if (ap == null) {
            em.persist(param);
            rt = true;
        }
        return rt;
    }

    @Override
    public void updateUserlogin(String username, String password, String datelastlogin, String timelastlogin, String locationlogin, String roleid, String status, String statuscomment) {
        Userlogin ul = em.find(Userlogin.class, username);
        if (ul != null) {
            if (password != null) {
                ul.setPassword(password);
            }
            if (datelastlogin != null) {
                ul.setDatelastlogin(datelastlogin);
            }
            if (timelastlogin != null) {
                ul.setTimelastlogin(timelastlogin);
            }
            if (locationlogin != null) {
                ul.setLocaltimlogin(locationlogin);
            }
            if (status != null) {
                ul.setStatus(status);
            }
            if (statuscomment != null) {
                ul.setStatuscomment(statuscomment);
            }
        }
    }

    @Override
    public Userlogin getUserlogin(String param) {
        return em.find(Userlogin.class, param);
    }

    @Override
    public boolean removeUserlogin(String param) {
        boolean rt = false;
        Userlogin ap = em.find(Userlogin.class, param);
        if (ap != null) {
            em.remove(ap);
            rt = true;
        }
        return rt;
    }
    Settings settings = new Settings();

    //Utility sessions
    @Override
    public LoginParameters login(String username, String password, String datelogin, String timelogin, String iplogin) {
        LoginParameters det = null;
        String pages;
        String defaulthome;
        String roles;
        String menu;

        try {
            Userlogin user = em.find(Userlogin.class, username);
            if (user != null) {
                if (user.getPassword().equals(password)) {
                    this.newUserloghistory(new Userloghistory((username + datelogin + settings.getPincodes(6)),
                            username, datelogin, timelogin, iplogin));
                    this.updateUserlogin(username, null, datelogin, timelogin, iplogin, null, null, null);
                    if (user.getStatus().equalsIgnoreCase("ACTIVE")) {
                        roles = user.getRoleid();
                        defaulthome = this.getDefaulthomepage(username);
                        pages = this.getPagesString(username);
                        menu = this.getDesignedMenu(username);
                        det = new LoginParameters(username, roles, defaulthome, pages, menu);
                    }

                } else {
                    this.newUserloghistory(new Userloghistory((username + datelogin + settings.getPincodes(6)),
                            username, datelogin, timelogin, iplogin));
                }
            }
        } catch (Exception f) {
            f.printStackTrace();
        }
        return det;
    }

    @Override
    public String getPagesString(String username) {
        String userPages = "";
        try {
            Userlogin ul = this.getUserlogin(username);
            if (ul != null) {
                String[] roleids = ul.getRoleid().split(";");
                for (String roleid : roleids) {
                    if (roleid.trim().length() > 0) {
                        List<Pages> pages = this.getAllPagesforRole(roleid);
                        for (Pages page : pages) {
                            if (!userPages.contains(page.getPagename())) {
                                userPages += (";" + page.getPagename());
                            }
                        }
                    }
                }
            }
        } catch (Exception ja) {
        }
        return userPages;
    }

    @Override
    public String getDefaulthomepage(String username) {
        String lp = "";
        try {
            Userlogin ul = this.getUserlogin(username);
            if (ul != null) {
                String firstRoleid = ul.getRoleid().split(";")[1];
                Roles ro = this.getRoles(firstRoleid);
                if (ro != null) {
                    lp = ro.getLogingpage();
                }
            }
        } catch (Exception js) {
        }
        return lp;
    }

    private String getDesignedMenu(String username) {
        List<Menus> tb = (List<Menus>) em.createNamedQuery("Menus.findAll").getResultList();
        String tabmenu = "";
        for (Menus tb1 : tb) {
            String[] pages = this.getPagesString(username).split(";");
            if (pages.length > 0) {
                tabmenu += "<h3>" + tb1.getMenuname() + "</h3><div>";
                for (String page : pages) {
                    Pages pagedet = this.getPagesByName(page);
                    if (pagedet != null) {
                        if (tb1.getMenuid().equalsIgnoreCase(pagedet.getMenuid())) {
                            if (pagedet.getStatus().equalsIgnoreCase("ACTIVE")) {
                                tabmenu += "<a href=\"" + pagedet.getPagename() + "\">" + pagedet.getDescription() + "</a><br/>";
                            } else {
                                tabmenu += "<a href=\"#\" title=\"This page has been deactivated " + pagedet.getStatuscomment() + "\">" + pagedet.getDescription() + "</a><br/>";
                            }
                        }
                    }
                }
                tabmenu += "</div>";
            }

        }

        return tabmenu;
    }

    @Override
    public boolean newMenus(Menus param) {
        boolean rt = false;
        Menus ap = em.find(Menus.class, param.getMenuid());
        if (ap == null) {
            em.persist(param);
            rt = true;
        }
        return rt;
    }

    @Override
    public List getAllMenus() {
        List<Menus> menu = new ArrayList();
        try {
            menu = (List<Menus>) em.createNamedQuery("Menus.findAll").getResultList();
        } catch (Exception j) {
        }
        return menu;
    }

    @Override
    public Menus getMenus(String param) {
        return em.find(Menus.class, param);
    }

    @Override
    public boolean removeMenus(String param) {
        boolean rt = false;
        Menus ap = em.find(Menus.class, param);
        if (ap != null) {
            em.remove(ap);
            rt = true;
        }
        return rt;
    }

//end of menu building and login controls
    @Override
    public Employee searchEmployee(String param) {
        Employee emp = null;
        try {
            emp = (Employee) em.createQuery("SELECT e FROM Employee e WHERE e.phone = :p OR e.email = :em OR e.fname = :fn").setParameter("p", param).setParameter("em", param).setParameter("fn", param).getSingleResult();
        } catch (Exception e) {
            System.out.println("Erro from Query Not working");
        }
        return emp;

    }

    @Override
    public List<Employee> searchEmployeeByParamenters(String param) {
        return em.createNamedQuery("Employee.findByFnamePhoneEmail").setParameter("phone", param).setParameter("fname", param).setParameter("email", param).setParameter("status", param).getResultList();
    }

    @Override
    public String checkUsername(String username) {
        Userlogin ul = null;
        try {
            ul = em.find(Userlogin.class, username);
        } catch (Exception e) {
        }
        return ul.getRoleid();
    }

    @Override
    public boolean validatePassword(String username, String password) {
        Userlogin ul = null;
        boolean bol = false;
        try {
            ul = em.find(Userlogin.class, username);
            bol = true;
        } catch (Exception e) {
            System.out.println(e.getMessage() + "error couldnot validate Password");
        }
        return (bol && ul.getPassword().equalsIgnoreCase(password));
    }

    @Override
    public boolean checkStatus(String username, String status) {
        boolean bol = false;
        Userlogin ul = null;
        try {
            ul = (Userlogin) em.createQuery("SELECT u FROM Userlogin u WHERE u.username = :username AND u.status = :status")
                    .setParameter("username", username)
                    .setParameter("Status", status)
                    .getSingleResult();
            bol = true;
        } catch (Exception e) {
        }
        return bol;
    }

    @Override
    public void createUsers(Userlogin user) {
        em.persist(user);
    }

    @Override
    public void disableuser(String username) {
        Userlogin cs = null;
        try {
            cs = em.find(Userlogin.class, username);
            em.merge(cs).setStatus("0");
        } catch (Exception poms) {
        }
    }

    @Override
    public void enableuser(String username) {
        Userlogin cs = null;
        try {
            cs = em.find(Userlogin.class, username);
            em.merge(cs).setStatus("1");
        } catch (Exception poms) {
        }
    }

    @Override
    public void disableProject(String projectid) {
        Projects cs = null;
        try {
            cs = em.find(Projects.class, projectid);
            cs.setDateEnded(settings.getTodaysdate());
            em.merge(cs).setState("Completed");
        } catch (Exception poms) {
        }
    }

    @Override
    public void enableProjects(String projectid) {
        Projects cs = null;
        try {
            cs = em.find(Projects.class, projectid);
            cs.setDateEnded("Pending");
            em.merge(cs).setState("Pending");
        } catch (Exception poms) {
        }
    }

    @Override
    public void disableProjectTarget(String targetid) {
        Employeetargets cs = null;
        try {
            cs = em.find(Employeetargets.class, targetid);
            //cs.setDateEnded(settings.getTodaysdate());
            em.merge(cs).setApproval("Completed");
        } catch (Exception poms) {
        }
    }

    @Override
    public void enableProjectsTargets(String targetid) {
        Employeetargets cs = null;
        try {
            cs = em.find(Employeetargets.class, targetid);
            cs.setApproval("Pending");
            em.merge(cs).setApproval("Pending");
        } catch (Exception poms) {
        }
    }
    
     @Override
    public void disableProjectTargetEmployee(String targetid) {
        Employeetargets cs = null;
        try {
            cs = em.find(Employeetargets.class, targetid);
            //cs.setDateEnded(settings.getTodaysdate());
            em.merge(cs).setStatus("Finish");
        } catch (Exception poms) {
        }
    }
   
    @Override
    public void enableProjectsTargetsEmployee(String targetid) {
        Employeetargets cs = null;
        try {
            cs = em.find(Employeetargets.class, targetid);
            //cs.setApproval("Pending");
            em.merge(cs).setStatus("Pending");
        } catch (Exception poms) {
        }
    }

    @Override
    public List<Userlogin> viewAllUsers() {
        return em.createNamedQuery("Userlogin.findAll").getResultList();
    }

    @Override
    public void changePassword(String uname, String newpw) {
        try {
            Userlogin ul = em.find(Userlogin.class, uname);
            if (ul != null) {
                ul.setPassword(newpw);
            }
        } catch (Exception j) {
        }
    }

    @Override
    public List<Userloghistory> viewUserloginHistoryByUsername(String username) {
        return em.createQuery("SELECT u FROM Userloghistory u WHERE u.username = :user ORDER BY u.datelastlogin DESC").setParameter("user", username).getResultList();
    }

    @Override
    public void createDepartment(Department dept) {
        em.persist(dept);
    }

    @Override
    public List<Department> viewDepartment() {
        return em.createNamedQuery("Department.findAll").getResultList();
    }

    @Override
    public void removeDepartment(String departmentcode) {
        Department dp = null;
        try {
            dp = em.find(Department.class, departmentcode);
            em.remove(dp);
        } catch (Exception e) {
        }
    }

    @Override
    public void removeProjects(String projectid) {
        Projects pj = null;
        try {
            pj = em.find(Projects.class, projectid);
            em.remove(pj);
        } catch (Exception e) {
        }
    }

    @Override
    public List<Projects> viewAllProjects() {
        return em.createNamedQuery("Projects.findAll").getResultList();
    }

    @Override
    public Projects viewSingleProject(String projectid) {
        return em.find(Projects.class, projectid);
    }

    @Override
    public List<Employeetargets> viewAllEmployeeTargets() {
        return em.createNamedQuery("Employeetargets.findAll").getResultList();
    }

    @Override
    public void removeEmployeetargets(String targetid) {
        Employeetargets pj = null;
        try {
            pj = em.find(Employeetargets.class, targetid);
            em.remove(pj);
        } catch (Exception e) {
        }
    }

    @Override
    public List<Employeetargets> viewEmployeeTargetsByEmployeeid(String employeeID) {
        return em.createNamedQuery("Employeetargets.findByEmployeeID").setParameter("employeeID", employeeID).getResultList();
    }

}
