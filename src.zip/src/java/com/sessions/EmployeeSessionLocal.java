/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sessions;

import com.entities.Department;
import com.entities.Employee;
import com.entities.Employeedepartment;
import com.entities.Employeepassport;
import com.entities.Employeetargets;
import com.entities.Menus;
import com.entities.Nextofkin;
import com.entities.Pages;
import com.entities.Projects;
import com.entities.Roles;
import com.entities.Userloghistory;
import com.entities.Userlogin;
import com.util.LoginParameters;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ManikTech
 */
@Local
public interface EmployeeSessionLocal {

    void persistNewEntry(Object obj);

    void deleteObject(Object obj);

    void updateRecord(Object obj);

    Object getSingleObject(Class<Object> ent, Object pk);

    void upLoadPicture(String employeeID, byte[] pic);

    byte[] viewVc(String employeeID);

    boolean newEmployeePassport(Employeepassport param);

    Employeepassport getEmployeePassport(String param);

    boolean removeEmployeePassport(String param);

    Employee viewSingleEmployee(String employeeID);

    List<Nextofkin> viewEmployeeNextOfKing(String employeeID);

    List<Employeedepartment> viewEmployeeDepartment(String employeeID);

    List<Employee> viewAllEmployee();

    void removeEmployeeDetails(String employeeID);

    String editEmployee(String employeeID, String title, String maritalStatus, String phone, String email, String contactAddress, String homeaddress, String idCardType, String idCardNumber);

    Employeedepartment viewEmployeeDepartmentByEmployeeID(String employeeID);

    Nextofkin viewNextofKingByEmployeeID(String employeeID);

    String editEmployeeDepatement(String id, String department, String jobTitle, String qalifications, String areaSpecialize, String rank);

    String editNextofKin(String id, String fullname, String gender, String relationship, String phone, String address, String occuption);

    boolean newMenus(Menus param);

    Menus getMenus(String param);

    boolean removeMenus(String param);

    boolean newPages(Pages param);

    Pages getPages(String param);

    boolean removePages(String param);

    boolean newRoles(Roles param);

    Roles getRoles(String param);

    boolean removeRoles(String param);

    public List getAllMenus();

    public List getAllPages();

    public Pages getPagesByName(String pagename);

    public List<Pages> getAllPagesforRole(String roleid);

    public List getAllRoles();

    public void updateUserlogin(String username, String password, String datelastlogin, String timelastlogin, String locationlogin, String roleid, String status, String statuscomment);

    public LoginParameters login(String username, String password, String datelogin, String timelogin, String iplogin);

    public String getDefaulthomepage(String username);

    public String getPagesString(String username);

    boolean newUserloghistory(Userloghistory param);

    Userloghistory getUserloghistory(String param);

    boolean removeUserloghistory(String param);

    boolean newUserlogin(Userlogin param);

    Userlogin getUserlogin(String param);

    boolean removeUserlogin(String param);

    Employee searchEmployee(String param);

    List<Employee> searchEmployeeByParamenters(String param);

    String checkUsername(String username);

    boolean validatePassword(String username, String password);

    boolean checkStatus(String username, String status);

    void createUsers(Userlogin user);

    void disableuser(String username);

    void enableuser(String username);

    List<Userlogin> viewAllUsers();

    void changePassword(String uname, String newpw);

    List<Userloghistory> viewUserloginHistoryByUsername(String username);

    void createDepartment(Department dept);

    List<Department> viewDepartment();

    void removeDepartment(String departmentcode);

    void disableProject(String projectid);

    void enableProjects(String projectid);

    void removeProjects(String projectid);

    List<Projects> viewAllProjects();

    Projects viewSingleProject(String projectid);

    List<Employeetargets> viewAllEmployeeTargets();

    void removeEmployeetargets(String targetid);

    List<Employeetargets> viewEmployeeTargetsByEmployeeid(String employeeID);

    void disableProjectTarget(String projectid);

    void enableProjectsTargets(String projectid);

    void disableProjectTargetEmployee(String targetid);

    void enableProjectsTargetsEmployee(String targetid);
}
