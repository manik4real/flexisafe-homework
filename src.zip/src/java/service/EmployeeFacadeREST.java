/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import com.entities.Employee;
import java.util.List;
import java.util.Random;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author ManikTech
 */
@Stateless
@Path("com.entities.employee")
public class EmployeeFacadeREST extends AbstractFacade<Employee> {

    @PersistenceContext(unitName = "EmployeePU")
    private EntityManager em;

    public EmployeeFacadeREST() {
        super(Employee.class);
    }

    @POST
    //employeeID, title, fname, onames, gender, dob, maritalStatus, phone, email, contactAddress, homeaddress, lga,
    //state, nationality, employmentDate, idCardType, idCardNumber, datecreated, status
    @Consumes("application/x-www-form-urlencoded")
    public String create(@FormParam("title") String title, @FormParam("fname") String fname, @FormParam("onames") String onames, @FormParam("gender") String gender, @FormParam("dob") String dob, @FormParam("maritalStatus") String maritalStatus, @FormParam("phone") String phone, @FormParam("email") String email,
            @FormParam("contactAddress") String contactAddress, @FormParam("homeaddress") String homeaddress, @FormParam("lga") String lga,
            @FormParam("state") String state, @FormParam("nationality") String nationality, @FormParam("employmentDate") String employementDate,
            @FormParam("idCardType") String idCardType, @FormParam("idCardNumber") String idCardNumber) {
        String msg ="";
        Employee ep = new Employee(this.generateEmployeeID());
        ep.setTitle(title);
        ep.setFname(fname);
        ep.setOnames(onames);
        ep.setGender(gender);
        ep.setDob(dob);
        ep.setMaritalStatus(maritalStatus);
        ep.setPhone(phone);
        ep.setEmail(email);
        ep.setContactAddress(contactAddress);
        ep.setHomeaddress(homeaddress);
        ep.setLga(lga);
        ep.setState(state);
        ep.setNationality(nationality);
        ep.setEmploymentDate(employementDate);
        ep.setIdCardType(idCardType);
        ep.setIdCardNumber(idCardNumber);
        ep.setStatus("Created");
        super.create(ep);
        return msg ="Employeee Created Successfully" +ep;
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") String id, Employee entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") String id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Employee find(@PathParam("id") String id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Employee> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Employee> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public String generateEmployeeID() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 8) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }

}
